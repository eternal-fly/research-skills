param(
  [Parameter(Mandatory=$true)][string]$Repository,
  [Parameter(Mandatory=$true)][string]$RevtexDirectory,
  [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path $Repository).Path
$revtex = (Resolve-Path $RevtexDirectory).Path.Replace('\','/')
$out = [System.IO.Path]::GetFullPath($OutputDirectory).Replace('\','/')
if (Test-Path $out) { throw 'Choose a new output directory for a clean two-pass build.' }
$env:TEXINPUTS = "$revtex//;"
if (-not ((Get-Content "$revtex/revtex4-2.cls" -Raw) -match '2022/06/05 4.2f')) { throw 'REVTeX 4.2f required' }
New-Item -ItemType Directory -Force $out | Out-Null
Set-Location "$root/skills/aps-quantum-writing/assets/heading-examples"
$sources = @('prl-chosen-headings','prl-unheaded-opening','prl-no-main-headings','regular-production-preview','nonprl-letter')
foreach ($source in $sources) {
  foreach ($pass in 1,2) {
    & pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -recorder "-output-directory=$out" "$source.tex" > "$out/$source.pass$pass.stdout" 2>&1
    $code = $LASTEXITCODE
    Copy-Item "$out/$source.log" "$out/$source.pass$pass.log"
    if ($code -ne 0) { throw "$source pass $pass failed with $code" }
    Write-Output "$source pass $pass exit=$code"
  }
}

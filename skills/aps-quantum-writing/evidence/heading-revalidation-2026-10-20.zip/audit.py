"""Recheck the five compiled release examples. Requires pdfplumber and Poppler."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
import pdfplumber

build = Path(sys.argv[1])
names = ['prl-chosen-headings', 'prl-unheaded-opening', 'prl-no-main-headings',
         'regular-production-preview', 'nonprl-letter']
checks = []
pages = {}
texts = {}
def check(name, ok, details=None):
    checks.append(dict(name=name, passed=bool(ok), details=details))

for name in names:
    with pdfplumber.open(build / (name + '.pdf')) as pdf:
        check(name + ': single page', len(pdf.pages) == 1)
        page = pdf.pages[0]
        pages[name] = page.chars
        check(name + ': glyphs within page', all(
            0 <= c['x0'] < c['x1'] <= page.width and 0 <= c['top'] < c['bottom'] <= page.height
            for c in page.chars))
    text = subprocess.check_output(['pdftotext', '-layout', str(build / (name + '.pdf')), '-'], encoding='utf-8')
    texts[name] = text
    (build / (name + '.txt')).write_text(text, encoding='utf-8')
    log = (build / (name + '.pass2.log')).read_text(errors='replace')
    check(name + ': REVTeX 4.2f', 'Document Class: revtex4-2 2022/06/05 4.2f' in log)
    bad = re.findall(r'^.*(?:Warning|Overfull|Underfull|Undefined control|Missing character|^!).*$', log, re.M)
    check(name + ': final log clean', not bad, bad)

def locate(name, label):
    chars = pages[name]
    stream = ''.join(c['text'] for c in chars)
    start = stream.index(label.replace(' ', ''))
    end = start + len(label.replace(' ', ''))
    offsets, pos = [], 0
    for c in chars:
        offsets.append((pos, pos + len(c['text']), c))
        pos += len(c['text'])
    selected = [c for a,b,c in offsets if a >= start and b <= end]
    following = next(c for a,b,c in offsets if a >= end and c['text'].strip())
    return selected, following

def runin(name, label, font, body):
    chars, nextchar = locate(name, label)
    check(name + ': ' + label + ' font', all(c['fontname'].split('+')[-1] == font for c in chars))
    check(name + ': ' + label + ' upright body', nextchar['fontname'].endswith('CMR10') and nextchar['text'] == body)
    delta = abs(chars[-1]['matrix'][5] - nextchar['matrix'][5])
    check(name + ': ' + label + ' shared baseline', delta < 0.02, delta)

for name, labels in {
    'prl-chosen-headings': [('Introduction', 'T'), ('Illustrative model', 'A'), ('Conclusions', 'T'), ('Note added.', 'T'), ('Acknowledgments', 'T'), ('Data availability', 'T')],
    'prl-unheaded-opening': [('Illustrative setup', 'O'), ('Outlook', 'T'), ('Acknowledgments', 'I'), ('Data availability', 'I')],
    'prl-no-main-headings': [('Acknowledgments', 'I'), ('Data availability', 'I')],
}.items():
    for label, first in labels:
        # Poppler independently verifies punctuation; pdfplumber supplies font/baseline.
        check(name + ': ' + label + ' punctuation', label + '\u2014' in texts[name])
        runin(name, label + '\u2014', 'CMTI10', first)

runin('prl-chosen-headings', 'Global fit:', 'CMR10', 'T')
runin('prl-chosen-headings', 'Boundary conditions.', 'CMTI10', 'A')
for label, first in [('Introduction', 'T'), ('Illustrative model', 'T'), ('Outlook', 'A'),
                     ('Acknowledgments', 'T'), ('Data availability', 'T'), ('Appendix: Illustrative derivation', 'T')]:
    check('Letter: ' + label + ' period', bool(re.search(re.escape(label) + r'\.\s+', texts['nonprl-letter'])))
    runin('nonprl-letter', label + '.', 'CMTI10', first)
check('Letter: no em dash', '\u2014' not in texts['nonprl-letter'])
runin('nonprl-letter', 'Global fit:', 'CMR10', 'A')

regular = 'regular-production-preview'
for label, font in [('I. ILLUSTRATIVE PRINCIPAL HEADING', 'CMBX9'),
                    ('A. Illustrative first subheading', 'CMBX9'),
                    ('1. Illustrative second subheading', 'CMBXTI10'),
                    ('ACKNOWLEDGMENTS', 'CMBX9'), ('DATA AVAILABILITY', 'CMBX9')]:
    chars, following = locate(regular, label)
    fonts = sorted(set(c['fontname'].split('+')[-1] for c in chars))
    check('Regular: ' + label + ' font', fonts == [font], fonts)
    check('Regular: ' + label + ' standalone', abs(chars[-1]['matrix'][5] - following['matrix'][5]) > 5)
    midpoint = (min(c['x0'] for c in chars) + max(c['x1'] for c in chars)) / 2
    # Letterpaper-independent column center from body left/right edges in this PDF.
    column_chars = [c for c in pages[regular] if c['top'] > 110 and (c['x0'] < 300) == (midpoint < 300)]
    center = (min(c['x0'] for c in column_chars) + max(c['x1'] for c in column_chars)) / 2
    check('Regular: ' + label + ' centered', abs(midpoint - center) < 1.0, round(midpoint - center, 4))
check('Regular: font hook enabled', 'Regular third-level bold font hooks enabled' in (build / (regular + '.pass2.log')).read_text())
for name, expected in [('prl-unheaded-opening', 4), ('prl-no-main-headings', 2)]:
    check(name + ': no inserted main heading', texts[name].count('\u2014') == expected)

result = {'scope': 'Fresh checks of five public examples only; not the historical 29-source/32-assertion suite.',
          'checks': checks, 'passed': sum(c['passed'] for c in checks), 'total': len(checks)}
(build / 'pdf-checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'passed': result['passed'], 'total': result['total'], 'failures': [c for c in checks if not c['passed']]}, indent=2))
sys.exit(0 if result['passed'] == result['total'] else 1)
